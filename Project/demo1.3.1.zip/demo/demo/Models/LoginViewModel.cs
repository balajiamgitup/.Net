﻿namespace demo.Models
{
    public class LoginViewModel
    {
        public string Name { get; set; }
        public string Password { get; set; }
    }
}
