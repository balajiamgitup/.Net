﻿namespace demo.Models.Domain
{
    public class Account
    {
        public string Name { get; set; }
        public string Password { get; set; }
    }
}
