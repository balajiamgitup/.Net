﻿using System.ComponentModel.DataAnnotations;

namespace demo.Models.Account
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        public string Uername { get; set; }
        public string Email { get; set; }
        public long? Mobile { get; set; }
        public string Password { get; set; }
        public bool IsActive { get; set; }
      

    }

}