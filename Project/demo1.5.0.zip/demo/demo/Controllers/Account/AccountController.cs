﻿using demo.Data;
using demo.Models;
using demo.Models.Account;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace demo.Controllers.Account
{
    public class AccountController : Controller
    {
        private readonly MvcDemoDbContents context;

        public AccountController(MvcDemoDbContents context)
        {
            this.context = context;
        }
     
        [HttpGet]
        public IActionResult login()
        {
            return View();
        }
        [AcceptVerbs("post","Get")]
        public IActionResult UserNameisExist(string userName)
        {
            var data = context.User.Where(e => e.Uername == userName).SingleOrDefault();
            if(data != null)
            {
                TempData["msg"] = $"Username {userName} already in use!";
                return Json($"Username{userName} already in use!");
            }
            else
            {
                return Json(true);
            }
        }
        
        [HttpPost]
        public IActionResult login(LoginSignUpViewModel model)
        {
            if (ModelState.IsValid)
            {
                var data = context.User.Where(e => e.Uername == model.Username).SingleOrDefault();
                if (data != null)
                {
                    bool isValid = (data.Uername == model.Username && data.Password == model.Password);
                    if (isValid)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, model.Username) }, CookieAuthenticationDefaults.AuthenticationScheme);
                        var principle = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principle);
                        HttpContext.Session.SetString("Username",model.Username);
                        return RedirectToAction("Privacy", "Home");
                    }
                    else
                    {
                        TempData["perrormessage"] = "Invalid password";
                        return View(model);
                    }
                }
                else
                {
                    TempData["errormessage"] = "Username not found!";
                    return View(model);
                }
            }
            else
            {
                return View(model);
            }
       
        }
        public IActionResult LogOut()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            var storedCookies = Request.Cookies.Keys;
            foreach(var cookies in storedCookies)
            {
                Response.Cookies.Delete(cookies);
            }
            return RedirectToAction("Login", "Account");
        }

        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(SignUpUserViewModel model)
        {
            if (ModelState.IsValid)
            {
                var data = new User()
                {
                    Uername = model.Username,
                    Email = model.Email,
                    Password = model.Password,
                    Mobile = model.Mobile,
                    IsActive=model.IsActive

                };
                context.User.Add(data);
                context.SaveChanges();
                TempData["successMessage"] = "You are eligible to login , Please fill on credential's then login!";
                return RedirectToAction("Login");
         
            }
            else
            {
                TempData["FerrorMessagse"] = "Empty form can't be submitted !";
                return View(model);
            }
            
        }

    }

}