﻿using demo.Data;
using demo.Models;
using demo.Models.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace demo.Controllers
{
    public class ProjectController : Controller
    {
        private readonly MvcDemoDbContents mvcProjectDbContext;

        public ProjectController(MvcDemoDbContents mvcProjectDbContext)
        {
            this.mvcProjectDbContext = mvcProjectDbContext;
        }
        [AllowAnonymous]
        [HttpGet]
     public async Task<IActionResult> PIndex()
        {
         var project =   await mvcProjectDbContext.Project.ToListAsync();
            return View(project);
        }
        [AllowAnonymous]
        [HttpGet]
        public IActionResult PAdd()
        {
            return View();
        }
        [AllowAnonymous]
        [Authorize]
        [HttpPost]
        public async Task< IActionResult> PAdd(AddProjectViewModel addProjectRequest)
        {
            var project = new Project()
            {
                SlNo = Guid.NewGuid(),
                DotNet = addProjectRequest.DotNet,
                Java = addProjectRequest.Java,
                Python = addProjectRequest.Python,
                NodeJs = addProjectRequest.NodeJs

            };
         await   mvcProjectDbContext.Project.AddAsync(project);
         await   mvcProjectDbContext.SaveChangesAsync();
            return RedirectToAction("PIndex");
        }
        [AllowAnonymous]
        [HttpGet]
        public async Task<IActionResult> PView(Guid id)
        {
            var project = await mvcProjectDbContext.Project.FirstOrDefaultAsync(x => x.SlNo == id);
            if( project != null)
            {
                var viewModel = new UpdateProjectViewModel()
                {
                   SlNo = project.SlNo,
                    DotNet = project.DotNet,
                    Java = project.Java,
                    Python = project.Python,
                    NodeJs = project.NodeJs,
                    

                };
                return await Task.Run(() => View("PView", viewModel));
            }
            return RedirectToAction("PIndex");
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> PView(UpdateProjectViewModel model)
        {
            var project = await mvcProjectDbContext.Project.FindAsync(model.SlNo);
            if (project != null)
            {
                project.SlNo = model.SlNo;
                project.DotNet = model.DotNet;
                project.Java = model.Java;
                project.Python = model.Python;
                project.NodeJs = model.NodeJs;

                await mvcProjectDbContext.SaveChangesAsync();

                return RedirectToAction("PIndex");


            }

            return RedirectToAction("PIndex");
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> PDelete(UpdateProjectViewModel model)
        {

            var  employee= await mvcProjectDbContext.Project.FindAsync(model.SlNo);

            if (employee != null)
            {
                mvcProjectDbContext.Project.Remove(employee);
                await mvcProjectDbContext.SaveChangesAsync();

                return RedirectToAction("PIndex");

            }
            return RedirectToAction("PIndex");
        }
    }
}
