﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace demo.Models
{
    public class SignUpUserViewModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="Please enter username")]
        [Remote(action: "UserNameisExist",controller:"Account")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Please enter Email")]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage ="Please enter the valid Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter Mobile Number")]
        [Display(Name ="Mobile Number")]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage ="Mobile number is not valid .")]
        public long? Mobile { get; set; }

        [Required(ErrorMessage = "Please enter Password")]
        public string Password { get; set; }


        [Required(ErrorMessage = "Please enter ConfirmPassword")]
        [Display(Name="confirm password ")]
        [Compare("Password",ErrorMessage =("confirm password can't matched!"))]
        public string ConfirmPassword { get; set; }

        [Display(Name ="Active")]
        public bool IsActive { get; set; }
 
    }
}
