﻿using System.ComponentModel.DataAnnotations;

namespace demo.Models
{
    public class AddEmployeeViewModel
    {
        [Required(ErrorMessage = "Please enter username")]
        public string Name { get; set; }
        public string Email { get; set; }
        public long Salary { get; set; }
        public DateTime DateofBirth { get; set; }
        public string Department { get; set; }
    }
}
