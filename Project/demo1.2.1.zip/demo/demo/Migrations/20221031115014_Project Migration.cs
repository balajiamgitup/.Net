﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace demo.Migrations
{
    public partial class ProjectMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Project",
                columns: table => new
                {
                    SlNo = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    DotNet = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Python = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NodeJs = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Java = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Project", x => x.SlNo);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Project");
        }
    }
}
