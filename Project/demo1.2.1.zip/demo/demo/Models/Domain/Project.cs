﻿using System.ComponentModel.DataAnnotations;

namespace demo.Models.Domain
{
    public class Project
    {
        [Key]
        public Guid SlNo { get; set; }

        public string   DotNet { get; set; }
        public string Python { get; set; }
        public string NodeJs  { get; set; }
        public string Java  { get; set; }
    }
}
