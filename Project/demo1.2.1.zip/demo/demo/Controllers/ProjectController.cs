﻿using demo.Data;
using demo.Models;
using demo.Models.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace demo.Controllers
{
    public class ProjectController : Controller
    {
        private readonly MvcDemoDbContents mvcProjectDbContext;

        public ProjectController(MvcDemoDbContents mvcProjectDbContext)
        {
            this.mvcProjectDbContext = mvcProjectDbContext;
        }

        [HttpGet]
     public async Task<IActionResult> PIndex()
        {
         var project =   await mvcProjectDbContext.Project.ToListAsync();
            return View(project);
        }

        [HttpGet]
        public IActionResult PAdd()
        {
            return View();
        }

        [HttpPost]
        public async Task< IActionResult> PAdd(AddProjectViewModel addProjectRequest)
        {
            var project = new Project()
            {
                SlNo = Guid.NewGuid(),
                DotNet = addProjectRequest.DotNet,
                Java = addProjectRequest.Java,
                Python = addProjectRequest.Python,
                NodeJs = addProjectRequest.NodeJs

            };
         await   mvcProjectDbContext.Project.AddAsync(project);
         await   mvcProjectDbContext.SaveChangesAsync();
            return RedirectToAction("PIndex");
        }
        [HttpGet]
        public async Task<IActionResult> PView(Guid id)
        {
            var project = await mvcProjectDbContext.Project.FirstOrDefaultAsync(x => x.SlNo == id);
            if( project != null)
            {
                var viewModel = new UpdateProjectViewModel()
                {
                   SlNo = project.SlNo,
                    DotNet = project.DotNet,
                    Java = project.Java,
                    Python = project.Python,
                    NodeJs = project.NodeJs,
                    

                };
                return await Task.Run(() => View("PView", viewModel));
            }
            return RedirectToAction("PIndex");
        }
    }
}
