﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace demo.Models
{
    public class AddEmployeeViewModel
    {
        [Required(ErrorMessage = "Please enter username")]
        [Remote(action: "UserNameisExist", controller: "Emp")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please enter Email")]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Please enter the valid Email")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Please enter Salary")]
        public long Salary { get; set; }
        [Required(ErrorMessage = "Please enter DateofBirth")]
        public DateTime DateofBirth { get; set; }
        [Required(ErrorMessage = "Please enter Department")]
        public string Department { get; set; }
    }
}
