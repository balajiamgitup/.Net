﻿using System.ComponentModel.DataAnnotations;

namespace demo.Models
{
    public class UpdateProjectViewModel
    {
        [Key]
        public Guid SlNo { get; set; }

        public string DotNet { get; set; }
        public string Python { get; set; }
        public string NodeJs { get; set; }
        public string Java { get; set; }
    }
}
