﻿namespace WebApplication1.Authentication
{
    public class Responce
    {
    }
}
