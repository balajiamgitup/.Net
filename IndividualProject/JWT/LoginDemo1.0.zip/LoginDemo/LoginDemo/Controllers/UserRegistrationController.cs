﻿using LoginDemo.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace LoginDemo.Controllers
{
    public class UserRegistrationController : Controller
    {
        public static string baseUrl = "http://localhost:5073/api/Authenticate/register";
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult CreateUser()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create([Bind("UserName,Email,Password ")] UserRegistration register)
        {
         //   var accessToken = HttpContext.Session.GetString("JWToken");
            var url = baseUrl;
            HttpClient client = new HttpClient();
           // client.DefaultRequestHeaders.Authorization=new AuthenticationHeaderValue("Bearer",accessToken);

            var stringContent=new StringContent(JsonConvert.SerializeObject(register),Encoding.UTF8,"application/Json");
            await client.PostAsync(url,stringContent);
            return RedirectToAction("Home", "Index");
        }
    }
}
